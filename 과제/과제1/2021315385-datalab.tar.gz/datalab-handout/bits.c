/*
 * SWE2001 Data Lab
 *
 * Gun Daniel Lee 2021315385
 *
 * bits.c - Source file with your solutions to the Lab.
 *          This is the file you will hand in to your instructor.
 *
 * WARNING: Do not include the <stdio.h> header; it confuses the dlc
 * compiler. You can still use printf for debugging without including
 * <stdio.h>, although you might get a compiler warning. In general,
 * it's not good practice to ignore compiler warnings, but in this
 * case it's OK.
 */

#if 0
/*
 * Instructions to Students:
 *
 * STEP 1: Read the following instructions carefully.
 */

// You will provide your solution to the Data Lab by
// editing the collection of functions in this source file.

// INTEGER CODING RULES:
//  
//   Replace the "return" statement in each function with one
//   or more lines of C code that implements the function. Your code 
//   must conform to the following style:
//  
//   int Funct(arg1, arg2, ...) {
//       /* brief description of how your implementation works */
//       int var1 = Expr1;
//       ...
//       int varM = ExprM;

//       varJ = ExprJ;
//       ...
//       varN = ExprN;
//       return ExprR;
//   }

//   Each "Expr" is an expression using ONLY the following:
//   1. Integer constants 0 through 255 (0xFF), inclusive. You are
//       not allowed to use big constants such as 0xffffffff.
//   2. Function arguments and local variables (no global variables).
//   3. Unary integer operations ! ~
//   4. Binary integer operations & ^ | + << >>
//     
//   Some of the problems restrict the set of allowed operators even further.
//   Each "Expr" may consist of multiple operators. You are not restricted to
//   one operator per line.

//   You are expressly forbidden to:
//   1. Use any control constructs such as if, do, while, for, switch, etc.
//   2. Define or use any macros.
//   3. Define any additional functions in this file.
//   4. Call any functions.
//   5. Use any other operations, such as &&, ||, -, or ?:
//   6. Use any form of casting.
//   7. Use any data type other than int.  This implies that you
//      cannot use arrays, structs, or unions.

//  
//   You may assume that your machine:
//   1. Uses 2s complement, 32-bit representations of integers.
//   2. Performs right shifts arithmetically.
//   3. Has unpredictable behavior when shifting if the shift amount
//      is less than 0 or greater than 31.


// EXAMPLES OF ACCEPTABLE CODING STYLE:
//   /*
//    * pow2plus1 - returns 2^x + 1, where 0 <= x <= 31
//    */
//   int pow2plus1(int x) {
//      /* exploit ability of shifts to compute powers of 2 */
//      return (1 << x) + 1;
//   }

//   /*
//    * pow2plus4 - returns 2^x + 4, where 0 <= x <= 31
//    */
//   int pow2plus4(int x) {
//      /* exploit ability of shifts to compute powers of 2 */
//      int result = (1 << x);
//      result += 4;
//      return result;
//   }

// FLOATING POINT CODING RULES

// For the problems that require you to implement floating-point operations,
// the coding rules are less strict.  You are allowed to use looping and
// conditional control.  You are allowed to use both ints and unsigneds.
// You can use arbitrary integer and unsigned constants. You can use any arithmetic,
// logical, or comparison operations on int or unsigned data.

// You are expressly forbidden to:
//   1. Define or use any macros.
//   2. Define any additional functions in this file.
//   3. Call any functions.
//   4. Use any form of casting.
//   5. Use any data type other than int or unsigned.  This means that you
//      cannot use arrays, structs, or unions.
//   6. Use any floating point data types, operations, or constants.


// NOTES:
//   1. Use the dlc (data lab checker) compiler (described in the handout) to 
//      check the legality of your solutions.
//   2. Each function has a maximum number of operations (integer, logical,
//      or comparison) that you are allowed to use for your implementation
//      of the function.  The max operator count is checked by dlc.
//      Note that assignment ('=') is not counted; you may use as many of
//      these as you want without penalty.
//   3. Use the btest test harness to check your functions for correctness.
//   4. Use the BDD checker to formally verify your functions
//   5. The maximum number of ops for each function is given in the
//      header comment for each function. If there are any inconsistencies 
//      between the maximum ops in the writeup and in this file, consider
//      this file the authoritative source.

/*
 * STEP 2: Modify the following functions according the coding rules.
 * 
 *   IMPORTANT. TO AVOID GRADING SURPRISES:
 *   1. Use the dlc compiler to check that your solutions conform
 *      to the coding rules.
 *   2. Use the BDD checker to formally verify that your solutions produce 
 *      the correct answers.
 */

#endif
/* Copyright (C) 1991-2021 Free Software Foundation, Inc.
   This file is part of the GNU C Library.

   The GNU C Library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2.1 of the License, or (at your option) any later version.

   The GNU C Library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.

   You should have received a copy of the GNU Lesser General Public
   License along with the GNU C Library; if not, see
   <https://www.gnu.org/licenses/>.  */
/* This header is separate from features.h so that the compiler can
   include it implicitly at the start of every compilation.  It must
   not itself include <features.h> or any other header that includes
   <features.h> because the implicit include comes before any feature
   test macros that may be defined in a source file before it first
   explicitly includes a system header.  GCC knows the name of this
   header in order to preinclude it.  */
/* glibc's intent is to support the IEC 559 math functionality, real
   and complex.  If the GCC (4.9 and later) predefined macros
   specifying compiler intent are available, use them to determine
   whether the overall intent is to support these features; otherwise,
   presume an older compiler has intent to support these features and
   define these macros by default.  */
/* wchar_t uses Unicode 10.0.0.  Version 10.0 of the Unicode Standard is
   synchronized with ISO/IEC 10646:2017, fifth edition, plus
   the following additions from Amendment 1 to the fifth edition:
   - 56 emoji characters
   - 285 hentaigana
   - 3 additional Zanabazar Square characters */
/* 
 * allEvenBits - return 1 if all even-numbered bits in word set to 1
 *   where bits are numbered from 0 (least significant) to 31 (most significant)
 *   Examples allEvenBits(0xFFFFFFFE) = 0, allEvenBits(0x55555555) = 1
 *   Legal ops: ! ~ & ^ | + << >>
 *   Max ops: 12
 *   Rating: 2
 */
int allEvenBits(int x) 
{
/* we can use the shift and & operators
 * everytime we shift to the right by 2 (since even-numbered bits), we compare with the stored variable, if it is the same, the bits would stay the same in a 010101 sort of pattern
 * this will go along until there is the last case 0x00000001
 * compare this with 1, if it stayed as 1, then the final answer will be 1, if not, it will become 0
*/
  x &= x >> 2;
  x &= x >> 4;
  x &= x >> 8;
  x &= x >> 16;
  return x & 1;
}
/* 
 * allOddBits - return 1 if all odd-numbered bits in word set to 1
 *   where bits are numbered from 0 (least significant) to 31 (most significant)
 *   Examples allOddBits(0xFFFFFFFD) = 0, allOddBits(0xAAAAAAAA) = 1
 *   Legal ops: ! ~ & ^ | + << >>
 *   Max ops: 12
 *   Rating: 2
 */
int allOddBits(int x) {
/*
*0x55 is an 8 bit pattern where all the even-numbered bits are 1
* we use shifting and adding such that int variable A becomes a 32 bit value with all even-numbered bits set to 1
* we can do this by shifting the adding 0x55 after shifting 8 bits at a time to fill in all the spots
* then we combine this bit with x using the | operator
* if x had all odd-numbered bit set to 1, then A | x would be all ones
* if the above case was satisfied, then using the ~ operator would let the bit become all 0 which is correct
* since we need 1 to show that it is correct, we can use the ! operator at the end
* for the ~ operator, it would only work if all odd-numbered bits were set to 1 in x, it would not otherwise
*/
  int A = 0x55;
  A += 0x55 << 8;
  A += 0x55 << 16;
  A += 0x55 << 24;
  return !(~(A | x));
}
/* 
 * bitAnd - x&y using only ~ and | 
 *   Example: bitAnd(6, 5) = 4
 *   Legal ops: ~ |
 *   Max ops: 8
 *   Rating: 1
 */
int bitAnd(int x, int y) {
/*
* first we use the ~ to flip the two integers, which means that the positions represented as 1 are the ones that should not exist in the final return value
* then we use the | operator to combine the two flipped integers, the positions that are shown as 1 now are all the positions that are not supposed to be in the final return value
* in other words, these are the ones that do not exist in both x and y
* we then use the ~ operator again to get our final value
*/
  return ~((~x) | (~y));
}
/* 
 * bitOr - x|y using only ~ and & 
 *   Example: bitOr(6, 5) = 7
 *   Legal ops: ~ &
 *   Max ops: 8
 *   Rating: 1
 */
int bitOr(int x, int y) {
/*
* Similarly to bitAnd, we use the ~ operator to flip both integers
* if we use the & operator with the both, the ones shown as 1 are the positions that were 0 for both integers
* now use ~ again to get the x | y value
*/
  return ~((~x) & (~y));
}
/* 
 * bitXor - x^y using only ~ and & 
 *   Example: bitXor(4, 5) = 1
 *   Legal ops: ~ &
 *   Max ops: 14
 *   Rating: 1
 */
int bitXor(int x, int y) {
/*
* we can use we can use the & operator to combine "not and" and "or"
* the | operator expressed by ~((~x) & (~y)), will become 1 if at least 1 exists in both
* this means that there are two cases within or, case1: both have it, case2: only one has it
* xor needs case2 where only one has it
* to eliminate case 1, we have to do the opposite of it, we can do this by getting the x & y, and using ~ to get the exact opposite
*by combining these two, we get xor
*/
  return ~(x & y) & ~((~x) & (~y));
}
/*
 * isTmax - returns 1 if x is the maximum, two's complement number,
 *     and 0 otherwise 
 *   Legal ops: ! ~ & ^ | +
 *   Max ops: 10
 *   Rating: 1
 */
int isTmax(int x) {
/*
* if x is the maximum of two's complement number, then the pattern would be 0111...
* add 1 to x and it would give the minimum or y = 1000000....
* combining these two together will give us -1 or z = 111111111....
* flip this and we get z = 0
* due to possible overflow situations (when x = -1), we have to double check
* since y must be the minimum value once 1 is added, then we can use the ! operator, and it must return 0
* z = 1111111..., when flipped must also return 1
* so when !y and ~z are added, the result must be 0
* if the result is 0, it is true but we need a 1 for true, so we use ! operator again
*/
  int y = x + 1;
  int z = y + x;
  z = ~z + !y;
  z = !z;
  return z;
}
/*
 * isTmin - returns 1 if x is the minimum, two's complement number,
 *     and 0 otherwise 
 *   Legal ops: ! ~ & ^ | +
 *   Max ops: 10
 *   Rating: 1
 */
int isTmin(int x) {
/*
* if x is the minimum, the pattern would be 10000...
* we can start by subtracting one to get the maximum 011111... through overflow
* now combine the minimum and maximum and flip it to get 0
* however, this would also work if we use x = 0
* so we can make sure that it is the minimum by adding the ! operator to x
* this value returning 0 showing that x is indeed negative
* so we can add this value to the flipped value of max + min
* if it was indeed the minimum, that value will still remain as 0
* to end, we use !: if the result was 0, then return 1 and otherwise, return 0
*/
  int y = x + ~0;
  int z = y + x;
  z = ~z + !x;
  z = !z;
  return z;
}
/* 
 * TMax - return maximum two's complement integer 
 *   Legal ops: ! ~ & ^ | + << >>
 *   Max ops: 4
 *   Rating: 1
 */
int tmax(void) {
/*
* the easiet way to get the maximum is to get the minimum integer first
* to get 10000...., we can shift 1 to the left 31 times
* flip this value then we get the maximum
*/
  return ~(1 << 31);
}
/* 
 * tmin - return minimum two's complement integer 
 *   Legal ops: ! ~ & ^ | + << >>
 *   Max ops: 4
 *   Rating: 1
 */
int tmin(void) {
/*
* similar to tmax, but in this case, if we just shift 1 to the left 31 times, it already is the minimum
*/
  return 1 << 31;
}
/* 
 * negate - return -x 
 *   Example: negate(1) = -1.
 *   Legal ops: ! ~ & ^ | + << >>
 *   Max ops: 5
 *   Rating: 2
 */
int negate(int x) {
/*
* To easily negate a value, it is the flipped pattern + 1
* this is because a value + its flipped = -1
* meaning that a flipped value is -1 more negative than -x (-x - 1)
* so we can just add one to counter the - 1
*/
  return (~x) + 1;
}
/* 
 * rotateLeft - Rotate x to the left by n
 *   Can assume that 0 <= n <= 31
 *   Examples: rotateLeft(0x87654321,4) = 0x76543218
 *   Legal ops: ~ & ^ | + << >> !
 *   Max ops: 25
 *   Rating: 3 
 */
int rotateLeft(int x, int n) {
/* y: bit value for the left side to make sure the left side is set to zero
	done by shifting to the left by n and adding ~0 (-1)
	for n = 4, 10000 + ~0 = 01111
  z: right shifted values, shift x to the right by 33 + ~n (or 32 - n) then use & with y to make sure left side is set to 0
  use | to combine z and x << n
*/
  int y = (1 << n) + ~0;
  int z = (x >> (33 + ~n)) & y;
  return (x << n) | z;
}
/* 
 * rotateRight - Rotate x to the right by n
 *   Can assume that 0 <= n <= 31
 *   Examples: rotateRight(0x87654321,4) = 0x187654321
 *   Legal ops: ~ & ^ | + << >> !
 *   Max ops: 25
 *   Rating: 3 
 */
int rotateRight(int x, int n) {
/* y: value to save the bits that shift from the right side to left
	done by left shifting 33 + ~n (or 32 - n)
* a: bit value to make sure left side of shift is set to 0
	done by 1 << (33 + ~n) + ~0 (-1)
* z: right shifted value (x >> n) & a (make sure left side is set to 0)
* return y | z to combine both
*/
  int y = x << (33 + ~n);
  int a = (1 << (33 + ~n)) + ~0;
  int z = (x >> n) & a;
  return y | z;
}
/* 
 * isAsciiDigit - return 1 if 0x30 <= x <= 0x39 (ASCII codes for characters '0' to '9')
 *   Example: isAsciiDigit(0x35) = 1.
 *            isAsciiDigit(0x3a) = 0.
 *            isAsciiDigit(0x05) = 0.
 *   Legal ops: ! ~ & ^ | + << >>
 *   Max ops: 15
 *   Rating: 3
 */
int isAsciiDigit(int x) {
/* sign: used to check the signs of the variables, also expresses the most negative value 100000....
*nine: conditional variable to check whether a value is <= 0x39
	~(sign | 0x30), adding values  > 0x39 will let this value become
	negative through overflow
*zero: conditional variable to check whether a value is >= 0x30
	~(0x30) + 1, adding values < 0x30 will let this value become negative
* sign & ((use nine or zero here) + x), adds the value x to either nine or zero and uses sign & to check whether the sign is negative or positive
* (use nine or zero here) >> 31, we only need the sign variable so we shift to the right 31 times
* if Ascii digit is right, it would have been positive giving us 0, but we want 1, so we use !, this would give 1 if true and 0 if false
*/
  int sign = 1 << 31;
  int nine = ~(sign | 0x39);
  int zero = (~0x30) + 1;
 
  nine = sign & (nine + x);
  zero = sign & (zero + x);
  nine = nine >> 31;
  zero = zero >> 31;
  return !(nine | zero);
}
/* 
 * floatFloat2Int - Return bit-level equivalent of expression (int) f
 *   for floating point argument f.
 *   Argument is passed as unsigned int, but
 *   it is to be interpreted as the bit-level representation of a
 *   single-precision floating point value.
 *   Anything out of range (including NaN and infinity) should return
 *   0x80000000u.
 *   Legal ops: Any integer/unsigned operations incl. ||, &&. also if, while
 *   Max ops: 30
 *   Rating: 4
 */
int floatFloat2Int(unsigned uf) {
/* initialize exponent, fraction, e with their definitions
* use the exponent bits to separate the infinity, NaN and denormalized value cases using if cases
	infinity, NaN: exponent = 11111111
		return 0x80000000u
	denormalized: exponent = 00000000, values betweeen 0 - 1
		return 0
	out of range integer values: return 0x80000000u
* add signed bit to fraction
* shift the fraction right or left depending on e
* if sign bit is 1 (negative value), negate the fraction (-fraction)
* else, return the fraction
*/
  int exponent = (uf >> 23) & 0xFF;
  int fraction = uf & 0x7FFFFF;
  int e = exponent - 127;
  if(exponent == 0x7F800000)
  {
    return 0x80000000u;
  }
  
  if(!exponent)
  {
    return 0;
  }
  
  if(e < 0)
  {
    return 0;
  }
  
  if(e > 30)
  {
    return 0x80000000u;
  }
  fraction = fraction | 0x800000;
  
  if(e >= 23)
  {
    fraction = fraction << (e - 23);
  }
  else
  {
    fraction = fraction >> (23 - e);
  }
  if((uf >> 31) & 1)
  {
    return -fraction;
  }
  return fraction;
}
